extends RefCounted
# Procedural low-poly models (placeholders). Replace with real .glb assets later.
static var _mats: Dictionary = {}
static var _lamp: StandardMaterial3D
static var _win: StandardMaterial3D
static var _coin: StandardMaterial3D

static func col(a: Array) -> Color:
	return Color(float(a[0]), float(a[1]), float(a[2]))

static func mat(c: Color) -> StandardMaterial3D:
	var k: String = c.to_html()
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.roughness = 0.85
		_mats[k] = m
	return _mats[k]

static func unshaded(c: Color) -> StandardMaterial3D:
	var k: String = "u" + c.to_html()
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.albedo_color = c
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.disable_fog = true
		_mats[k] = m
	return _mats[k]

static func _emis(base: Color, glow: Color, e: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = base
	m.emission_enabled = true
	m.emission = glow
	m.emission_energy_multiplier = e
	return m

static func lamp() -> StandardMaterial3D:
	if _lamp == null:
		_lamp = _emis(Color(1, 0.95, 0.7), Color(1, 0.85, 0.5), 0.0)
	return _lamp

static func win() -> StandardMaterial3D:
	if _win == null:
		_win = _emis(Color(0.55, 0.7, 0.85), Color(1, 0.8, 0.45), 0.0)
	return _win

static func coin_mat() -> StandardMaterial3D:
	if _coin == null:
		_coin = _emis(Color(1, 0.8, 0.1), Color(1, 0.7, 0), 1.0)
	return _coin

static func set_night(n: float) -> void:
	lamp().emission_energy_multiplier = n * 4.0
	win().emission_energy_multiplier = n * 2.5

static func box(p: Node, size: Vector3, pos: Vector3, c: Color, m: Material = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m if m != null else mat(c)
	mi.position = pos
	p.add_child(mi)
	return mi

static func cyl(p: Node, rt: float, rb: float, h: float, pos: Vector3, c: Color, m: Material = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = rt
	cm.bottom_radius = rb
	cm.height = h
	cm.radial_segments = 8
	mi.mesh = cm
	mi.material_override = m if m != null else mat(c)
	mi.position = pos
	p.add_child(mi)
	return mi

static func sphere(p: Node, r: float, pos: Vector3, c: Color, m: Material = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 10
	sm.rings = 5
	mi.mesh = sm
	mi.material_override = m if m != null else mat(c)
	mi.position = pos
	p.add_child(mi)
	return mi

static func label3d(p: Node, t: String, pos: Vector3, size: int = 80) -> Label3D:
	var l := Label3D.new()
	l.text = t
	l.font_size = size
	l.pixel_size = 0.012
	l.outline_size = 14
	l.position = pos
	p.add_child(l)
	return l

# ---------------- Character ----------------
static func capsule(p: Node, r: float, h: float, pos: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = r
	cm.height = maxf(h, r * 2.0)
	cm.radial_segments = 10
	cm.rings = 4
	mi.mesh = cm
	mi.material_override = mat(c)
	mi.position = pos
	p.add_child(mi)
	return mi

static func make_character(d: Dictionary) -> Node3D:
	var path: String = str(d.get("model", ""))
	if path != "":
		var m := glb(path)
		if m != null:
			return _wrap_model(m, d)
	var r := Node3D.new()
	var skin := col(d["skin"])
	var shirt := col(d["shirt"])
	var pants := col(d["pants"])
	var hair := col(d["hair"])
	var shoes := col(d["shoes"])
	var outfit: String = str(d.get("outfit", "pants"))
	var style: String = str(d.get("hair_style", "short"))
	var torso := capsule(r, 0.3, 1.0, Vector3(0, 1.15, 0), shirt)
	torso.scale = Vector3(1, 1, 0.7)
	sphere(r, 0.26, Vector3(0, 1.84, 0), skin)
	sphere(r, 0.04, Vector3(0, 1.8, -0.26), skin.darkened(0.15))
	for s in [-1.0, 1.0]:
		sphere(r, 0.045, Vector3(s * 0.1, 1.88, -0.23), Color.WHITE)
		sphere(r, 0.025, Vector3(s * 0.1, 1.88, -0.27), Color(0.05, 0.05, 0.05))
	var hm := sphere(r, 0.285, Vector3(0, 1.93, 0.04), hair)
	hm.scale = Vector3(1, 0.8, 1)
	match style:
		"long":
			capsule(r, 0.17, 0.75, Vector3(0, 1.6, 0.2), hair)
		"ponytail":
			var pt := capsule(r, 0.07, 0.55, Vector3(0, 1.8, 0.33), hair)
			pt.rotation_degrees.x = -35
		"bun":
			sphere(r, 0.13, Vector3(0, 2.18, 0.05), hair)
		"cap":
			var cc: Color = col(d["cap"]) if d.has("cap") else shirt
			var dome := sphere(r, 0.3, Vector3(0, 1.97, 0.02), cc)
			dome.scale = Vector3(1, 0.65, 1)
			box(r, Vector3(0.3, 0.03, 0.22), Vector3(0, 1.93, -0.32), cc)
	match outfit:
		"dress":
			cyl(r, 0.22, 0.45, 0.6, Vector3(0, 0.82, 0), shirt)
		"panjabi":
			cyl(r, 0.3, 0.37, 0.95, Vector3(0, 0.95, 0), shirt)
	var legs: Array = []
	var arms: Array = []
	for s in [-1.0, 1.0]:
		var pv := Node3D.new()
		pv.position = Vector3(s * 0.15, 0.78, 0)
		r.add_child(pv)
		capsule(pv, 0.1, 0.78, Vector3(0, -0.38, 0), pants)
		box(pv, Vector3(0.2, 0.12, 0.34), Vector3(0, -0.74, -0.05), shoes)
		legs.append(pv)
		var av := Node3D.new()
		av.position = Vector3(s * 0.4, 1.5, 0)
		r.add_child(av)
		capsule(av, 0.075, 0.66, Vector3(0, -0.3, 0), skin)
		sphere(av, 0.09, Vector3(0, -0.64, 0), skin)
		arms.append(av)
	r.set_meta("legs", legs)
	r.set_meta("arms", arms)
	return r

# ---------------- Vehicles / obstacles (front faces -Z) ----------------
static func make_vehicle(v: Dictionary) -> Node3D:
	var n := Node3D.new()
	var s: Array = v["size"]
	var c := col(v["color"])
	match str(v.get("model", "vehicle")):
		"horse": _horse(n, c)
		"barrier": _barrier(n, s, c)
		"beam": _beam(n, s, c)
		"log": _log(n, s, c)
		"truck": _truck(n, s, c)
		_: _vehicle(n, s, c)
	blob(n, float(s[0]) * 1.3, float(s[2]) * 1.15)
	return n

static func _wheels_lights(n: Node3D, w: float, l: float) -> void:
	for z in [-0.3 * l, 0.3 * l]:
		box(n, Vector3(w + 0.1, 0.7, 0.8), Vector3(0, 0.35, z), Color(0.05, 0.05, 0.05))
	for x in [-1.0, 1.0]:
		box(n, Vector3(0.3, 0.2, 0.1), Vector3(x * w * 0.35, 0.8, -l / 2.0 - 0.02), Color.WHITE, lamp())
		box(n, Vector3(0.3, 0.2, 0.1), Vector3(x * w * 0.35, 0.8, l / 2.0 + 0.02), Color(0.8, 0, 0))

static func _vehicle(n: Node3D, s: Array, c: Color) -> void:
	var w: float = s[0]
	var h: float = s[1]
	var l: float = s[2]
	box(n, Vector3(w, h - 0.35, l), Vector3(0, 0.35 + (h - 0.35) / 2.0, 0), c)
	box(n, Vector3(w + 0.04, (h - 0.35) * 0.3, l * 0.8), Vector3(0, 0.35 + (h - 0.35) * 0.65, 0), Color(0.12, 0.18, 0.25))
	_wheels_lights(n, w, l)

static func _truck(n: Node3D, s: Array, c: Color) -> void:
	var w: float = s[0]
	var h: float = s[1]
	var l: float = s[2]
	box(n, Vector3(w, 2.4, 2.4), Vector3(0, 1.2, -l / 2.0 + 1.2), c)
	box(n, Vector3(w * 0.9, 0.7, 0.05), Vector3(0, 1.7, -l / 2.0 - 0.01), Color(0.12, 0.18, 0.25))
	box(n, Vector3(w, h - 0.5, l - 2.7), Vector3(0, 0.5 + (h - 0.5) / 2.0, 1.35), Color(0.55, 0.45, 0.3))
	_wheels_lights(n, w, l)

static func _horse(n: Node3D, c: Color) -> void:
	box(n, Vector3(0.55, 0.75, 1.4), Vector3(0, 1.15, 0), c)
	var neck := box(n, Vector3(0.28, 0.8, 0.3), Vector3(0, 1.65, -0.7), c)
	neck.rotation_degrees.x = 25
	box(n, Vector3(0.26, 0.3, 0.6), Vector3(0, 2.0, -1.0), c)
	box(n, Vector3(0.08, 0.6, 0.2), Vector3(0, 1.85, -0.5), Color(0.1, 0.07, 0.04))
	box(n, Vector3(0.1, 0.7, 0.1), Vector3(0, 1.0, 0.75), Color(0.1, 0.07, 0.04))
	for x in [-0.18, 0.18]:
		for z in [-0.55, 0.55]:
			box(n, Vector3(0.14, 0.8, 0.14), Vector3(x, 0.4, z), c.darkened(0.3))

static func _barrier(n: Node3D, s: Array, c: Color) -> void:
	var w: float = s[0]
	box(n, Vector3(w, 0.4, 0.25), Vector3(0, 0.5, 0), c)
	box(n, Vector3(w * 0.25, 0.42, 0.27), Vector3(-w * 0.25, 0.5, 0), Color.WHITE)
	box(n, Vector3(w * 0.25, 0.42, 0.27), Vector3(w * 0.25, 0.5, 0), Color.WHITE)
	for x in [-0.8, 0.8]:
		box(n, Vector3(0.1, 0.5, 0.1), Vector3(x, 0.25, 0), Color(0.2, 0.2, 0.2))

static func _beam(n: Node3D, s: Array, c: Color) -> void:
	for x in [-1.0, 1.0]:
		cyl(n, 0.08, 0.08, 2.2, Vector3(x, 1.1, 0), Color(0.3, 0.3, 0.3))
	box(n, Vector3(s[0], 0.8, 0.2), Vector3(0, 1.5, 0), c)
	box(n, Vector3(s[0] * 0.8, 0.12, 0.22), Vector3(0, 1.5, 0), Color.WHITE)

static func _log(n: Node3D, _s: Array, c: Color) -> void:
	var t := cyl(n, 0.4, 0.4, 2.2, Vector3(0, 0.4, 0), c)
	t.rotation_degrees.z = 90
	sphere(n, 0.5, Vector3(0.9, 0.5, 0), Color(0.15, 0.45, 0.15))

# ---------------- Environment ----------------
static func mango(p: Node, pos: Vector3) -> void:
	var t := Node3D.new()
	t.position = pos
	p.add_child(t)
	cyl(t, 0.3, 0.4, 3.0, Vector3(0, 1.5, 0), Color(0.4, 0.28, 0.15))
	var crown := Node3D.new()
	crown.position = Vector3(0, 3, 0)
	t.add_child(crown)
	crown.add_to_group("sway")
	sphere(crown, 2.2, Vector3(0, 1.0, 0), Color(0.12, 0.45, 0.15))
	sphere(crown, 1.5, Vector3(1.3, 0.4, 0.4), Color(0.16, 0.52, 0.2))

static func palm(p: Node, pos: Vector3) -> void:
	var t := Node3D.new()
	t.position = pos
	p.add_child(t)
	cyl(t, 0.2, 0.3, 7.0, Vector3(0, 3.5, 0), Color(0.45, 0.35, 0.22))
	var crown := Node3D.new()
	crown.position = Vector3(0, 7, 0)
	t.add_child(crown)
	crown.add_to_group("sway")
	for i in 5:
		var pv := Node3D.new()
		pv.rotation.y = i * TAU / 5.0
		crown.add_child(pv)
		var lf := box(pv, Vector3(0.5, 0.08, 3.2), Vector3(0, 0, -1.5), Color(0.15, 0.5, 0.18))
		lf.rotation_degrees.x = 15

static func bamboo(p: Node, pos: Vector3) -> void:
	var t := Node3D.new()
	t.position = pos
	p.add_child(t)
	t.add_to_group("sway")
	for i in 5:
		var b := cyl(t, 0.08, 0.1, randf_range(6.0, 8.0), Vector3(randf_range(-1, 1), 3.5, randf_range(-1, 1)), Color(0.4, 0.6, 0.2))
		b.rotation_degrees.z = randf_range(-8, 8)

static func banana(p: Node, pos: Vector3) -> void:
	var t := Node3D.new()
	t.position = pos
	p.add_child(t)
	cyl(t, 0.2, 0.25, 2.2, Vector3(0, 1.1, 0), Color(0.45, 0.6, 0.25))
	var crown := Node3D.new()
	crown.position = Vector3(0, 2.2, 0)
	t.add_child(crown)
	crown.add_to_group("sway")
	for i in 4:
		var pv := Node3D.new()
		pv.rotation.y = i * TAU / 4.0
		crown.add_child(pv)
		var lf := box(pv, Vector3(0.7, 0.05, 1.8), Vector3(0, 0, -0.9), Color(0.25, 0.65, 0.2))
		lf.rotation_degrees.x = 20

static func house(p: Node, pos: Vector3) -> void:
	var h := Node3D.new()
	h.position = pos
	h.rotation.y = randf_range(-0.3, 0.3)
	p.add_child(h)
	var c: Color = [Color(0.85, 0.75, 0.55), Color(0.7, 0.85, 0.8), Color(0.9, 0.6, 0.5)].pick_random()
	box(h, Vector3(4, 2.5, 4), Vector3(0, 1.25, 0), c)
	var r1 := box(h, Vector3(2.8, 0.12, 4.6), Vector3(-1.2, 2.95, 0), Color(0.55, 0.6, 0.65))
	r1.rotation_degrees.z = 20
	var r2 := box(h, Vector3(2.8, 0.12, 4.6), Vector3(1.2, 2.95, 0), Color(0.55, 0.6, 0.65))
	r2.rotation_degrees.z = -20
	box(h, Vector3(0.8, 1.5, 0.1), Vector3(-0.8, 0.75, 2.02), Color(0.3, 0.2, 0.1))
	box(h, Vector3(0.7, 0.6, 0.1), Vector3(1.0, 1.5, 2.02), Color.WHITE, win())

static func pond(p: Node, pos: Vector3) -> void:
	box(p, Vector3(8, 0.04, 6), Vector3(pos.x, 0.03, pos.z), Color(0.2, 0.5, 0.7))

static func paddy(p: Node, pos: Vector3) -> void:
	box(p, Vector3(10, 0.05, 8), Vector3(pos.x, 0.03, pos.z), Color(0.55, 0.75, 0.25))

static func cow(p: Node, pos: Vector3) -> void:
	var c: Color = [Color(0.95, 0.95, 0.9), Color(0.45, 0.3, 0.2)].pick_random()
	var n := Node3D.new()
	n.position = pos
	n.rotation.y = randf() * TAU
	p.add_child(n)
	box(n, Vector3(1.3, 0.8, 0.5), Vector3(0, 0.9, 0), c)
	box(n, Vector3(0.4, 0.4, 0.4), Vector3(0.8, 1.1, 0), c)
	for x in [-0.5, 0.5]:
		for z in [-0.18, 0.18]:
			box(n, Vector3(0.1, 0.6, 0.1), Vector3(x, 0.3, z), c.darkened(0.3))

static func mosque(p: Node, pos: Vector3) -> void:
	box(p, Vector3(6, 3.5, 6), pos + Vector3(0, 1.75, 0), Color(0.95, 0.95, 0.92))
	sphere(p, 2.2, pos + Vector3(0, 3.6, 0), Color(0.2, 0.6, 0.35))
	for x in [-3.0, 3.0]:
		cyl(p, 0.35, 0.4, 7.0, pos + Vector3(x, 3.5, 3), Color(0.9, 0.9, 0.85))

static func building(p: Node, pos: Vector3, side: float) -> void:
	var w := randf_range(6.0, 9.0)
	var h := randf_range(8.0, 22.0)
	var d := randf_range(6.0, 9.0)
	var c: Color = [Color(0.8, 0.75, 0.65), Color(0.7, 0.7, 0.75), Color(0.85, 0.6, 0.5), Color(0.6, 0.7, 0.8)].pick_random()
	box(p, Vector3(w, h, d), pos + Vector3(0, h / 2.0, 0), c)
	var x := pos.x - side * (w / 2.0 + 0.02)
	for k in int(h / 3.5):
		box(p, Vector3(0.05, 1.0, d * 0.8), Vector3(x, 2.0 + k * 3.5, pos.z), Color.WHITE, win())

static func shop(p: Node, pos: Vector3, side: float) -> void:
	var c: Color = [Color(0.9, 0.8, 0.5), Color(0.6, 0.8, 0.7), Color(0.9, 0.6, 0.6)].pick_random()
	box(p, Vector3(5, 3.2, 4.5), pos + Vector3(0, 1.6, 0), c)
	var a: Color = [Color(0.9, 0.2, 0.2), Color(0.2, 0.5, 0.9), Color(0.95, 0.7, 0.1)].pick_random()
	box(p, Vector3(1.6, 0.15, 5.2), pos + Vector3(-side * 3.0, 2.7, 0), a)
	box(p, Vector3(0.05, 0.9, 3.5), pos + Vector3(-side * 2.52, 1.2, 0), Color.WHITE, win())

static func pole(p: Node, pos: Vector3) -> void:
	cyl(p, 0.1, 0.12, 7.0, pos + Vector3(0, 3.5, 0), Color(0.5, 0.5, 0.5))
	box(p, Vector3(2.0, 0.1, 0.1), pos + Vector3(0, 6.6, 0), Color(0.3, 0.2, 0.1))

static func streetlight(p: Node, pos: Vector3, side: float) -> void:
	cyl(p, 0.07, 0.1, 6.0, pos + Vector3(0, 3, 0), Color(0.3, 0.3, 0.32))
	box(p, Vector3(1.8, 0.1, 0.1), pos + Vector3(-side * 0.9, 6.0, 0), Color(0.3, 0.3, 0.32))
	box(p, Vector3(0.6, 0.15, 0.35), pos + Vector3(-side * 1.7, 5.92, 0), Color.WHITE, lamp())

static func cloud(p: Node, pos: Vector3) -> void:
	for i in 3:
		var s := sphere(p, randf_range(3.0, 5.0), pos + Vector3(i * 4.0 - 4.0, randf(), 0), Color.WHITE, unshaded(Color(1, 1, 1)))
		s.scale = Vector3(1.6, 0.6, 1.0)

static func arch(p: Node, z: float, text: String) -> void:
	for x in [-5.0, 5.0]:
		box(p, Vector3(0.3, 6.0, 0.3), Vector3(x, 3.0, z), Color(0.8, 0.8, 0.8))
	box(p, Vector3(10.6, 1.5, 0.3), Vector3(0, 6.3, z), Color(0.1, 0.4, 0.25))
	label3d(p, text, Vector3(0, 6.3, z + 0.2), 90)

static func station(p: Node, z: float, text: String) -> void:
	box(p, Vector3(10, 5, 18), Vector3(13, 2.5, z), Color(0.95, 0.9, 0.75))
	box(p, Vector3(11, 0.6, 19), Vector3(13, 5.3, z), Color(0.6, 0.15, 0.15))
	box(p, Vector3(6, 1.0, 40), Vector3(22, 0.5, z), Color(0.7, 0.7, 0.7))
	for x in [27.0, 28.5]:
		box(p, Vector3(0.15, 0.2, 60), Vector3(x, 0.1, z), Color(0.3, 0.3, 0.3))
	var l := label3d(p, text, Vector3(7.9, 4.0, z), 110)
	l.rotation.y = -PI / 2.0

# ---------------- Shadows / weather / tiger / heart ----------------
static var _blob: StandardMaterial3D
static var _road: StandardMaterial3D
static var _rain: StandardMaterial3D
static var _heartm: StandardMaterial3D

# Soft contact shadow (works even on LOW quality where real shadows are off).
static func blob(p: Node, sx: float, sz: float) -> void:
	if _blob == null:
		_blob = StandardMaterial3D.new()
		_blob.albedo_color = Color(0, 0, 0, 0.35)
		_blob.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_blob.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var mi := cyl(p, 0.5, 0.5, 0.01, Vector3(0, 0.045, 0), Color.BLACK, _blob)
	mi.scale = Vector3(sx, 1, sz)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

static func road_mat() -> StandardMaterial3D:
	if _road == null:
		_road = StandardMaterial3D.new()
		_road.albedo_color = Color(0.18, 0.18, 0.2)
		_road.roughness = 0.9
	return _road

static func set_wet(w: float) -> void:
	var m := road_mat()
	m.roughness = lerpf(0.9, 0.12, w)
	m.metallic = 0.35 * w
	m.albedo_color = Color(0.18, 0.18, 0.2).darkened(0.4 * w)
	for gm in _wet_mats:
		gm.roughness = lerpf(0.9, 0.12, w)
		gm.metallic = 0.35 * w
		gm.albedo_color = Color.WHITE.darkened(0.4 * w)

static func rain_mat() -> StandardMaterial3D:
	if _rain == null:
		_rain = StandardMaterial3D.new()
		_rain.albedo_color = Color(0.8, 0.88, 1.0, 0.45)
		_rain.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_rain.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return _rain

static func heart(p: Node) -> void:
	if _heartm == null:
		_heartm = _emis(Color(1, 0.2, 0.4), Color(1, 0.2, 0.4), 0.8)
	var c := Color(1, 0.2, 0.4)
	sphere(p, 0.2, Vector3(-0.14, 0.12, 0), c, _heartm)
	sphere(p, 0.2, Vector3(0.14, 0.12, 0), c, _heartm)
	var b := box(p, Vector3(0.3, 0.3, 0.28), Vector3(0, -0.04, 0), c, _heartm)
	b.rotation_degrees.z = 45

static func make_tiger() -> Node3D:
	var n := Node3D.new()
	var o := Color(0.95, 0.5, 0.1)
	var k := Color(0.08, 0.05, 0.03)
	var body := capsule(n, 0.45, 1.9, Vector3(0, 1.0, 0), o)
	body.rotation_degrees.x = 90
	for i in 5:
		box(n, Vector3(0.5, 0.1, 0.1), Vector3(0, 1.43, -0.7 + i * 0.35), k)
	var head := sphere(n, 0.38, Vector3(0, 1.25, -1.15), o)
	head.scale = Vector3(1, 0.9, 1)
	for x in [-1.0, 1.0]:
		sphere(n, 0.1, Vector3(x * 0.25, 1.58, -1.1), k)
		sphere(n, 0.05, Vector3(x * 0.15, 1.32, -1.5), Color(1, 0.9, 0.1), unshaded(Color(1, 0.9, 0.1)))
	box(n, Vector3(0.3, 0.2, 0.25), Vector3(0, 1.15, -1.5), Color(1, 0.85, 0.6))
	box(n, Vector3(0.1, 0.07, 0.05), Vector3(0, 1.25, -1.63), k)
	var tail := capsule(n, 0.06, 1.1, Vector3(0, 1.3, 1.25), o)
	tail.rotation_degrees.x = -50
	var legs: Array = []
	for x in [-0.28, 0.28]:
		for z in [-0.65, 0.65]:
			var pv := Node3D.new()
			pv.position = Vector3(x, 0.85, z)
			n.add_child(pv)
			capsule(pv, 0.1, 0.85, Vector3(0, -0.4, 0), o)
			box(pv, Vector3(0.2, 0.1, 0.28), Vector3(0, -0.82, -0.04), k)
			legs.append(pv)
	n.set_meta("legs", legs)
	blob(n, 1.5, 2.8)
	return n

# ---------------- GLB loading (characters & road) ----------------
static var _scenes: Dictionary = {}
static var _wet_mats: Array = []

# Returns an instance of a .glb (imported PackedScene) or null if missing/invalid -> procedural fallback.
static func glb(path: String) -> Node3D:
	if not ResourceLoader.exists(path):
		return null
	if not _scenes.has(path):
		_scenes[path] = load(path)
	var ps: Variant = _scenes[path]
	if ps is PackedScene:
		var inst: Node = ps.instantiate()
		if inst is Node3D:
			return inst as Node3D
		inst.free()
	return null

static func _collect(n: Node, xf: Transform3D, out: Array) -> void:
	if n is MeshInstance3D:
		out.append(xf * (n as MeshInstance3D).get_aabb())
	for c in n.get_children():
		if c is Node3D:
			_collect(c, xf * (c as Node3D).transform, out)

static func measure(root: Node3D) -> AABB:
	var out: Array = []
	_collect(root, Transform3D.IDENTITY, out)
	if out.is_empty():
		return AABB(Vector3.ZERO, Vector3.ONE)
	var a: AABB = out[0]
	for i in range(1, out.size()):
		a = a.merge(out[i])
	return a

static func _register_wet(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		for i in mi.get_surface_override_material_count():
			var m: Material = mi.get_active_material(i)
			if m is StandardMaterial3D and m.resource_name == "asphalt" and not (m in _wet_mats):
				_wet_mats.append(m)
	for c in n.get_children():
		_register_wet(c)

# Road tile glb (any size) auto-fitted to total_w x seg_len, bottom at y=-0.1, running along -Z.
static func road_piece(seg_len: float, total_w: float) -> Node3D:
	var inst := glb("res://models/road/road_segment.glb")
	if inst == null:
		return null
	var holder := Node3D.new()
	holder.add_child(inst)
	var a := measure(inst)
	var sx: float = total_w / maxf(a.size.x, 0.001)
	var sz: float = seg_len / maxf(a.size.z, 0.001)
	var c := a.get_center()
	inst.scale = Vector3(sx, sx, sz)
	inst.position = Vector3(-c.x * sx, -0.1 - a.position.y * sx, -seg_len / 2.0 - c.z * sz)
	_register_wet(inst)
	return holder

# Character glb: optional nodes named LegL/LegR/ArmL/ArmR get code-driven run animation;
# otherwise the glb's own AnimationPlayer ("run" or first clip) is played.
static func _wrap_model(m: Node3D, d: Dictionary) -> Node3D:
	var r := Node3D.new()
	m.rotation_degrees.y = float(d.get("model_yaw", 0.0))
	m.scale = Vector3.ONE * float(d.get("model_scale", 1.0))
	r.add_child(m)
	var legs: Array = []
	var arms: Array = []
	for nm in ["LegL", "LegR"]:
		var n := m.find_child(nm, true, false)
		if n is Node3D:
			legs.append(n)
	for nm in ["ArmL", "ArmR"]:
		var n := m.find_child(nm, true, false)
		if n is Node3D:
			arms.append(n)
	if legs.size() != 2:
		legs = []
	if arms.size() != 2:
		arms = []
	r.set_meta("legs", legs)
	r.set_meta("arms", arms)
	var aps := m.find_children("*", "AnimationPlayer", true, false)
	if legs.is_empty() and not aps.is_empty():
		var ap: AnimationPlayer = aps[0]
		var names := ap.get_animation_list()
		var pick := ""
		for a in names:
			if "run" in String(a).to_lower():
				pick = String(a)
		if pick == "" and names.size() > 0:
			pick = String(names[0])
		if pick != "":
			ap.play(pick)
	return r
