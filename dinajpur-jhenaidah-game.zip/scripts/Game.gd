extends Node
# Autoload: data, local save, settings, missions, sfx.
const SAVE_PATH := "user://save.json"
const BACKUP_PATH := "user://save_backup.json"
var characters: Array = []
var routes: Array = []
var vehicles: Array = []
var missions: Array = []
var save: Dictionary = {}

var _loops: Dictionary = {}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	characters = _j("res://data/characters.json")
	routes = _j("res://data/routes.json")
	vehicles = _j("res://data/vehicles.json")
	missions = _j("res://data/missions.json")
	load_save()
	music_apply()

func _j(p: String) -> Variant:
	return JSON.parse_string(FileAccess.get_file_as_string(p))

func _default() -> Dictionary:
	return {"coins": 5, "unlocked": ["boy_01", "girl_01"], "selected": "boy_01", "best_score": 0,
		"direction": "fwd", "tokens": 2, "claimed": [], "progress": {"fwd": 0, "rev": 0},
		"stats": {"coins": 0, "meters": 0, "cps": 0, "runs": 0}, "updated": 0,
		"settings": {"music": true, "sound": true, "vibration": true, "quality": 1, "fps": 60, "lang": "bn", "cloud_url": ""}}

func load_save() -> void:
	var d := _default()
	if FileAccess.file_exists(SAVE_PATH):
		var p: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
		if p is Dictionary:
			var st: Dictionary = d["settings"]
			st.merge(p.get("settings", {}), true)
			p.erase("settings")
			d.merge(p, true)
	save = d
	apply_settings()

func write_save() -> void:
	save["updated"] = Time.get_unix_time_from_system()
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(save))

func apply_settings() -> void:
	Engine.max_fps = int(save["settings"]["fps"])

func backup_local() -> void:
	write_save()
	DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)

func restore_local() -> bool:
	if not FileAccess.file_exists(BACKUP_PATH):
		return false
	DirAccess.copy_absolute(BACKUP_PATH, SAVE_PATH)
	load_save()
	return true

func reset_all() -> void:
	save = _default()
	write_save()
	apply_settings()

func char_by_id(id: String) -> Dictionary:
	for c in characters:
		if c["id"] == id:
			return c
	return characters[0]

func is_unlocked(id: String) -> bool:
	return id in save["unlocked"]

func unlock(id: String) -> bool:
	var price: int = int(char_by_id(id)["price"])
	if is_unlocked(id):
		return true
	if int(save["coins"]) < price:
		return false
	save["coins"] = int(save["coins"]) - price
	save["unlocked"].append(id)
	write_save()
	return true

func route_data() -> Dictionary:
	var base: Dictionary = routes[0]
	var stops: Array = base["stops"].duplicate(true)
	var L: float = float(base["length_km"])
	if save["direction"] == "rev":
		stops.reverse()
		for s in stops:
			s["at"] = L - float(s["at"])
	return {"dir": save["direction"], "from": stops[0]["name"], "to": stops[stops.size() - 1]["name"],
		"length_km": L, "m_per_km": base["m_per_km"], "stops": stops}

func save_progress(i: int) -> void:
	var p: Dictionary = save["progress"]
	var d: String = save["direction"]
	p[d] = maxi(int(p.get(d, 0)), i)
	write_save()

# Called once when a run ends. Returns newly completed missions.
func end_run(st: Dictionary, completed: bool) -> Array:
	save["coins"] = int(save["coins"]) + int(st["coins"]) + (50 if completed else 0)
	save["best_score"] = maxi(int(save["best_score"]), int(st["score"]))
	var s: Dictionary = save["stats"]
	s["coins"] = int(s["coins"]) + int(st["coins"])
	s["meters"] = int(s["meters"]) + int(st["distance_m"])
	s["cps"] = int(s["cps"]) + int(st["cps"])
	s["runs"] = int(s["runs"]) + 1
	var done: Array = []
	for m in missions:
		if m["id"] in save["claimed"]:
			continue
		if int(s.get(m["type"], 0)) >= int(m["target"]):
			save["claimed"].append(m["id"])
			save["coins"] = int(save["coins"]) + int(m["reward"])
			done.append(m)
	write_save()
	return done

func sfx(n: String, db: float = 0.0) -> void:
	if not save["settings"]["sound"]:
		return
	var p := "res://audio/%s.wav" % n
	if not ResourceLoader.exists(p):
		return
	var pl := AudioStreamPlayer.new()
	pl.stream = load(p)
	pl.volume_db = db
	add_child(pl)
	pl.play()
	pl.finished.connect(pl.queue_free)

func loop_start(n: String, db: float = -6.0) -> void:
	if _loops.has(n):
		return
	var flag: String = "music" if n == "music" else "sound"
	if not save["settings"][flag]:
		return
	var p := "res://audio/%s.wav" % n
	if not ResourceLoader.exists(p):
		return
	var st: AudioStreamWAV = (load(p) as AudioStreamWAV).duplicate()
	st.loop_mode = AudioStreamWAV.LOOP_FORWARD
	st.loop_begin = 0
	st.loop_end = st.data.size() / 2
	var pl := AudioStreamPlayer.new()
	pl.stream = st
	pl.volume_db = db
	add_child(pl)
	pl.play()
	_loops[n] = pl

func loop_stop(n: String) -> void:
	if _loops.has(n):
		_loops[n].queue_free()
		_loops.erase(n)

func music_apply() -> void:
	if save["settings"]["music"]:
		loop_start("music", -12.0)
	else:
		loop_stop("music")

func vibrate() -> void:
	if save["settings"]["vibration"]:
		Input.vibrate_handheld(120)
