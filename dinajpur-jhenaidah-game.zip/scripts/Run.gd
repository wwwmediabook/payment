extends Node3D
# Gameplay world: 3 lanes, track-segment recycling, traffic, coins, power-ups, day/night, checkpoints.
signal died(stats: Dictionary)
signal finished(stats: Dictionary)
signal toast(text: String)

const Builder = preload("res://scripts/Builder.gd")
const LANES := [-2.2, 0.0, 2.2]
const SEG_LEN := 40.0
const SEG_COUNT := 7
const PU := ["magnet", "shield", "speed", "multiplier", "superjump"]
var PU_COL := [Color(0.9, 0.2, 0.2), Color(0.2, 0.5, 1), Color(1, 0.9, 0.1), Color(0.7, 0.3, 0.9), Color(0.2, 0.9, 0.4)]
var KEYS := [0.0, 0.45, 0.7, 0.85, 1.0]
var SKY := [Color(0.45, 0.72, 1.0), Color(0.45, 0.72, 1.0), Color(1.0, 0.5, 0.25), Color(0.03, 0.05, 0.14), Color(0.03, 0.05, 0.14)]
var SUN_E := [1.2, 1.2, 0.8, 0.05, 0.05]
var SUN_A := [-60.0, -55.0, -12.0, -4.0, -4.0]

var route: Dictionary
var ch: Dictionary
var mpk := 40.0
var total_m := 4000.0
var dens := 1.0
var rng := RandomNumberGenerator.new()
var player: Node3D
var model: Node3D
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var moon: MeshInstance3D
var sky: Node3D
var alive := true
var lane := 1
var px := 0.0
var py := 0.0
var vy := 0.0
var sliding := 0.0
var speed := 13.0
var base_speed := 13.0
var coins := 0
var bonus := 0
var elapsed := 0.0
var next_cp := 1
var cps_done := 0
var shield := 0.0
var magnet := 0.0
var boost := 0.0
var mult := 0.0
var superjump := 0.0
var segs: Array = []
var next_idx := 0
var obstacles: Array = []
var items: Array = []
var swipe_start := Vector2.ZERO
var swiping := false
var skymat: ProceduralSkyMaterial
var rain: CPUParticles3D
var rain_amt := 0.0
var rain_on := false
var weather_t := 18.0
var flash := 0.0
var thunder_t := 6.0
var tiger: Node3D
var tiger_gap := 6.0
var growl_t := 8.0
var pblob: Node3D

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	rng.randomize()
	route = Game.route_data()
	ch = Game.char_by_id(Game.save["selected"])
	mpk = float(route["m_per_km"])
	total_m = float(route["length_km"]) * mpk
	var q: int = int(Game.save["settings"]["quality"])
	dens = [0.5, 0.75, 1.0, 1.3][q]
	_make_env(q)
	player = Node3D.new()
	add_child(player)
	model = Builder.make_character(ch)
	player.add_child(model)
	pblob = Node3D.new()
	add_child(pblob)
	Builder.blob(pblob, 1.0, 1.0)
	tiger = Builder.make_tiger()
	add_child(tiger)
	_make_rain()
	cam = Camera3D.new()
	cam.far = 260.0
	add_child(cam)
	cam.make_current()
	sky = Node3D.new()
	add_child(sky)
	moon = Builder.sphere(sky, 7.0, Vector3(30, 55, -190), Color.WHITE, Builder.unshaded(Color(0.95, 0.95, 0.85)))
	for i in 40:
		Builder.sphere(sky, 0.5, Vector3(randf_range(-120, 120), randf_range(30, 90), -200), Color.WHITE, Builder.unshaded(Color.WHITE))
	base_speed = 13.0 * float(ch["speed"])
	if str(ch.get("ability", "none")) == "start_shield":
		shield = 4.0
	_ensure()
	_daylight(0.0)

func _make_env(q: int) -> void:
	env = Environment.new()
	skymat = ProceduralSkyMaterial.new()
	var sk := Sky.new()
	sk.sky_material = skymat
	env.background_mode = Environment.BG_SKY
	env.sky = sk
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = true
	env.fog_density = 0.01
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = q >= 1
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)
	get_viewport().msaa_3d = Viewport.MSAA_2X if q >= 2 else Viewport.MSAA_DISABLED

# Weather hook: add rain particles / wet-road shader here later.
func set_weather(w: String) -> void:
	env.fog_density = 0.03 if w == "fog" else 0.01

# ---------------- Input ----------------
func _input(e: InputEvent) -> void:
	var mb := e as InputEventMouseButton
	if mb:
		swiping = mb.pressed
		swipe_start = mb.position
	var mm := e as InputEventMouseMotion
	if mm and swiping:
		var d: Vector2 = mm.position - swipe_start
		if d.length() > 40.0:
			swiping = false
			if absf(d.x) > absf(d.y):
				_move(1 if d.x > 0 else -1)
			elif d.y < 0:
				_jump()
			else:
				_slide()
	var k := e as InputEventKey
	if k and k.pressed and not k.echo:
		match k.keycode:
			KEY_LEFT, KEY_A: _move(-1)
			KEY_RIGHT, KEY_D: _move(1)
			KEY_UP, KEY_W, KEY_SPACE: _jump()
			KEY_DOWN, KEY_S: _slide()

func _move(dx: int) -> void:
	if alive:
		lane = clampi(lane + dx, 0, 2)

func _jump() -> void:
	if alive and py <= 0.01:
		vy = 10.0 * float(ch["jump"]) * (1.45 if superjump > 0.0 else 1.0)
		sliding = 0.0
		Game.sfx("jump")

func _slide() -> void:
	if not alive:
		return
	if py > 0.01:
		vy = -16.0
	sliding = 0.7

# ---------------- Main loop ----------------
func _process(dt: float) -> void:
	if not alive:
		return
	elapsed += dt
	var dist: float = -player.position.z
	var prog: float = clampf(dist / total_m, 0.0, 1.0)
	var tgt: float = base_speed + prog * 9.0
	if boost > 0.0:
		tgt *= 1.45
	speed = lerpf(speed, tgt, dt * 1.5)
	player.position.z -= speed * dt
	px = lerpf(px, LANES[lane], clampf(dt * 12.0, 0.0, 1.0))
	player.position.x = px
	_player_phys(dt)
	shield = maxf(shield - dt, 0.0)
	magnet = maxf(magnet - dt, 0.0)
	boost = maxf(boost - dt, 0.0)
	mult = maxf(mult - dt, 0.0)
	superjump = maxf(superjump - dt, 0.0)
	_obstacles(dt)
	_items(dt)
	_checkpoints(dist)
	_ensure()
	_weather(dt)
	_tiger(dt)
	_daylight(prog)
	pblob.position = Vector3(px, 0, player.position.z)
	pblob.scale = Vector3.ONE * (1.0 / (1.0 + py * 0.6))
	cam.position = Vector3(px * 0.6, 4.2, player.position.z + 8.5)
	cam.look_at(Vector3(px * 0.6, 1.2, player.position.z - 9.0))
	cam.fov = lerpf(cam.fov, 70.0 + (speed - 13.0) * 0.6, dt * 2.0)
	sky.position.z = player.position.z
	for n in get_tree().get_nodes_in_group("sway"):
		n.rotation.z = sin(elapsed * 1.6 + n.position.x * 0.5 + float(n.get_instance_id() % 7)) * 0.025

func _player_phys(dt: float) -> void:
	if py > 0.0 or vy > 0.0:
		vy -= 28.0 * dt
		py += vy * dt
		if py <= 0.0:
			py = 0.0
			vy = 0.0
	player.position.y = py
	if sliding > 0.0:
		sliding -= dt
	model.scale.y = 0.55 if sliding > 0.0 else 1.0
	var legs: Array = model.get_meta("legs")
	var arms: Array = model.get_meta("arms")
	var sw: float = sin(elapsed * speed * 0.8)
	if legs.size() == 2 and arms.size() == 2:
		if py > 0.0:
			legs[0].rotation.x = 0.7
			legs[1].rotation.x = -0.4
			arms[0].rotation.x = -1.0
			arms[1].rotation.x = -1.0
		else:
			legs[0].rotation.x = sw * 0.9
			legs[1].rotation.x = -sw * 0.9
			arms[0].rotation.x = -sw * 0.8
			arms[1].rotation.x = sw * 0.8
	else:
		model.rotation.z = sw * 0.04

func _obstacles(dt: float) -> void:
	var ph: float = 0.8 if sliding > 0.0 else 1.8
	for o in obstacles.duplicate():
		var n: Node3D = o["node"]
		if not is_instance_valid(n):
			obstacles.erase(o)
			continue
		n.position.z += float(o["vel"]) * dt
		var dz: float = n.position.z - player.position.z
		if dz > 14.0:
			n.queue_free()
			obstacles.erase(o)
			continue
		if not o["horned"] and float(o["vel"]) > 0.0 and dz < 0.0 and dz > -35.0 \
				and (str(o["id"]).ends_with("bus") or o["id"] == "truck"):
			o["horned"] = true
			Game.sfx("horn")
		if absf(dz) < float(o["hz"]) + 0.35 and absf(n.position.x - px) < float(o["hx"]) + 0.3 \
				and py < float(o["ty"]) and py + ph > float(o["by"]):
			if shield > 0.0:
				n.queue_free()
				obstacles.erase(o)
				tiger_gap = 3.2
				Game.sfx("crash", -8.0)
			else:
				_die()
				return

func _items(dt: float) -> void:
	var mag_r: float = 8.0 if magnet > 0.0 else (3.0 if str(ch.get("ability", "")) == "passive_magnet" else 0.0)
	var target: Vector3 = player.position + Vector3(0, 0.9, 0)
	for it in items.duplicate():
		var n: Node3D = it["node"]
		n.rotation.y += dt * 3.0
		var dz: float = n.position.z - player.position.z
		if dz > 8.0:
			n.queue_free()
			items.erase(it)
			continue
		if mag_r > 0.0 and it["kind"] == "coin" and n.position.distance_to(target) < mag_r:
			n.position = n.position.move_toward(target, 25.0 * dt)
			dz = n.position.z - player.position.z
		if absf(dz) < 1.0 and absf(n.position.x - px) < 1.0 and absf(n.position.y - (py + 0.9)) < 1.3:
			_collect(str(it["kind"]))
			n.queue_free()
			items.erase(it)

func _collect(k: String) -> void:
	if k == "coin":
		coins += (2 if mult > 0.0 else 1)
		Game.sfx("coin")
		return
	if k == "heart":
		Game.save["tokens"] = int(Game.save["tokens"]) + 1
		Game.write_save()
		Game.sfx("love")
		toast.emit("ভালোবাসা! +১ রিভাইভ টোকেন")
		return
	var d: float = 8.0 * (1.5 if str(ch.get("ability", "")) == "long_powerup" else 1.0)
	Game.sfx("powerup")
	match k:
		"magnet": magnet = d
		"shield": shield = d
		"speed": boost = d
		"multiplier": mult = d
		"superjump": superjump = d

func _checkpoints(dist: float) -> void:
	var stops: Array = route["stops"]
	if next_cp >= stops.size():
		return
	var st: Dictionary = stops[next_cp]
	if dist < float(st["at"]) * mpk:
		return
	Game.save_progress(next_cp)
	if next_cp == stops.size() - 1:
		alive = false
		finished.emit(stats())
	else:
		coins += 10
		cps_done += 1
		bonus += 500
		toast.emit("চেকপয়েন্ট: %s   +10 কয়েন" % str(st["name"]))
		next_cp += 1

func _die() -> void:
	alive = false
	model.rotation.x = -0.6
	tiger_gap = 2.0
	tiger.position.z = player.position.z + 2.0
	Game.sfx("tiger")
	Game.vibrate()
	Game.sfx("crash")
	died.emit(stats())

func revive() -> void:
	for o in obstacles.duplicate():
		var n: Node3D = o["node"]
		if is_instance_valid(n) and n.position.z < player.position.z + 6.0 and n.position.z > player.position.z - 40.0:
			n.queue_free()
			obstacles.erase(o)
	lane = 1
	py = 0.0
	vy = 0.0
	shield = 4.0
	tiger_gap = 2.5
	model.rotation.x = 0.0
	alive = true

func stats() -> Dictionary:
	var dist: float = maxf(-player.position.z, 0.0)
	return {"distance_m": dist, "km": dist / mpk, "coins": coins, "score": int(dist * 10.0) + coins * 50 + bonus,
		"time": elapsed, "cps": cps_done}

func info() -> Dictionary:
	var s := stats()
	var pu := ""
	if magnet > 0.0: pu += "MAGNET %d  " % ceili(magnet)
	if shield > 0.0: pu += "SHIELD %d  " % ceili(shield)
	if boost > 0.0: pu += "SPEED %d  " % ceili(boost)
	if mult > 0.0: pu += "x2 COIN %d  " % ceili(mult)
	if superjump > 0.0: pu += "JUMP %d" % ceili(superjump)
	s["pu"] = pu
	s["total_km"] = float(route["length_km"])
	return s

# ---------------- Day / night ----------------
func _daylight(p: float) -> void:
	var i := 0
	while i < KEYS.size() - 2 and p > KEYS[i + 1]:
		i += 1
	var t: float = clampf((p - KEYS[i]) / (KEYS[i + 1] - KEYS[i]), 0.0, 1.0)
	var c: Color = SKY[i].lerp(SKY[i + 1], t)
	var night: float = clampf((p - 0.65) / 0.2, 0.0, 1.0)
	var ev: float = clampf(1.0 - absf(p - 0.7) / 0.2, 0.0, 1.0)
	c = c.lerp(Color(0.35, 0.38, 0.43).lerp(Color.BLACK, night * 0.8), rain_amt * 0.65)
	c = c.lerp(Color(0.9, 0.93, 1.0), flash)
	skymat.sky_top_color = c.darkened(0.3)
	skymat.sky_horizon_color = c.lerp(Color.WHITE, 0.25)
	skymat.ground_horizon_color = c
	skymat.ground_bottom_color = c.darkened(0.4)
	env.fog_light_color = c
	env.fog_density = 0.01 + 0.015 * rain_amt
	env.ambient_light_color = c.lerp(Color.WHITE, 0.4)
	env.ambient_light_energy = (1.0 - 0.45 * night) * (1.0 - 0.25 * rain_amt) + flash * 1.5
	sun.light_energy = lerpf(SUN_E[i], SUN_E[i + 1], t) * (1.0 - 0.55 * rain_amt) + flash
	sun.light_color = Color.WHITE.lerp(Color(1, 0.6, 0.35), ev)
	sun.rotation_degrees = Vector3(lerpf(SUN_A[i], SUN_A[i + 1], t), -30.0, 0.0)
	Builder.set_night(clampf(night + rain_amt * 0.5, 0.0, 1.0))
	Builder.set_wet(rain_amt)
	sky.visible = night > 0.4 and rain_amt < 0.5

# ---------------- Rain / thunder / tiger ----------------
func _make_rain() -> void:
	rain = CPUParticles3D.new()
	rain.amount = 260
	rain.lifetime = 0.7
	rain.emitting = false
	rain.local_coords = true
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(9, 0.1, 12)
	rain.direction = Vector3(0, -1, 0)
	rain.spread = 3.0
	rain.gravity = Vector3(0, -30, 0)
	rain.initial_velocity_min = 14.0
	rain.initial_velocity_max = 18.0
	var bm := BoxMesh.new()
	bm.size = Vector3(0.025, 0.7, 0.025)
	bm.material = Builder.rain_mat()
	rain.mesh = bm
	rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(rain)

func _weather(dt: float) -> void:
	weather_t -= dt
	if weather_t <= 0.0:
		rain_on = rng.randf() < 0.45
		weather_t = rng.randf_range(25.0, 45.0)
		if rain_on:
			toast.emit("বৃষ্টি শুরু হয়েছে!")
	rain_amt = move_toward(rain_amt, 1.0 if rain_on else 0.0, dt * 0.3)
	var wet := rain_amt > 0.25
	if wet and not rain.emitting:
		rain.emitting = true
		Game.loop_start("rain", -8.0)
	elif not wet and rain.emitting:
		rain.emitting = false
		Game.loop_stop("rain")
	rain.position = Vector3(px, 15.0, player.position.z - 4.0)
	if rain_amt > 0.5:
		thunder_t -= dt
		if thunder_t <= 0.0:
			thunder_t = rng.randf_range(7.0, 16.0)
			flash = 1.0
			get_tree().create_timer(0.6).timeout.connect(_thunder_sound)
	flash = maxf(flash - dt * 4.0, 0.0)

func _thunder_sound() -> void:
	Game.sfx("thunder")

func _tiger(dt: float) -> void:
	tiger_gap = move_toward(tiger_gap, 6.0, dt * 0.8)
	var sw: float = sin(elapsed * speed * 0.7)
	tiger.position = Vector3(lerpf(tiger.position.x, px, dt * 6.0), absf(sw) * 0.15, player.position.z + tiger_gap)
	var legs: Array = tiger.get_meta("legs")
	legs[0].rotation.x = sw * 0.8
	legs[1].rotation.x = -sw * 0.8
	legs[2].rotation.x = -sw * 0.8
	legs[3].rotation.x = sw * 0.8
	growl_t -= dt
	if growl_t <= 0.0:
		growl_t = rng.randf_range(12.0, 20.0)
		Game.sfx("tiger", -6.0)

func _exit_tree() -> void:
	Game.loop_stop("rain")

# ---------------- Track segments (recycled) ----------------
func _ensure() -> void:
	while (next_idx - 1) * SEG_LEN < -player.position.z + SEG_LEN * (SEG_COUNT - 2):
		var seg: Node3D
		if segs.size() < SEG_COUNT:
			seg = Node3D.new()
			add_child(seg)
			segs.append(seg)
		else:
			seg = segs.pop_front()
			segs.append(seg)
			for c in seg.get_children():
				c.queue_free()
		seg.position = Vector3(0, 0, -next_idx * SEG_LEN)
		_build_seg(seg, next_idx)
		next_idx += 1

func _biome_at(m: float) -> String:
	if m > total_m - 300.0:
		return "station"
	var b := "village"
	for st in route["stops"]:
		if float(st["at"]) * mpk <= m:
			b = str(st["biome"])
	return b

func _build_seg(seg: Node3D, idx: int) -> void:
	var m0: float = idx * SEG_LEN
	var biome := _biome_at(m0)
	var gc := Color(0.35, 0.62, 0.25) if biome == "village" else Color(0.42, 0.52, 0.36)
	Builder.box(seg, Vector3(80, 0.2, SEG_LEN), Vector3(0, -0.1, -SEG_LEN / 2.0), gc)
	var rp := Builder.road_piece(SEG_LEN, 10.8)
	if rp != null:
		seg.add_child(rp)
	else:
		Builder.box(seg, Vector3(7.6, 0.2, SEG_LEN), Vector3(0, -0.08, -SEG_LEN / 2.0), Color.WHITE, Builder.road_mat())
		for x in [-3.6, 3.6]:
			Builder.box(seg, Vector3(0.12, 0.02, SEG_LEN), Vector3(x, 0.03, -SEG_LEN / 2.0), Color(0.9, 0.9, 0.9))
		for x in [-1.1, 1.1]:
			for k in 5:
				Builder.box(seg, Vector3(0.12, 0.02, 2.2), Vector3(x, 0.03, -4.0 - k * 8.0), Color(0.95, 0.95, 0.95))
	_decor(seg, biome)
	var stops: Array = route["stops"]
	for i in range(1, stops.size()):
		var sm: float = float(stops[i]["at"]) * mpk
		if sm >= m0 and sm < m0 + SEG_LEN:
			Builder.arch(seg, -(sm - m0), str(stops[i]["name"]))
			if i == stops.size() - 1:
				Builder.station(seg, -(sm - m0), str(stops[i]["name"]))
	for k in 4:
		var m: float = m0 + 6.0 + k * 10.0
		if m < 60.0 or m > total_m - 40.0:
			continue
		var prog: float = m / total_m
		if rng.randf() < 0.55 + 0.3 * prog:
			_spawn_row(-m)

func _decor(seg: Node3D, biome: String) -> void:
	for side in [-1.0, 1.0]:
		var z := -3.0
		while z > -SEG_LEN:
			_item(seg, biome, Vector3(side * rng.randf_range(8.5, 20.0), 0.0, z), side)
			z -= rng.randf_range(5.0, 10.0) / dens
		for lz in [-10.0, -30.0]:
			if biome == "village":
				Builder.pole(seg, Vector3(side * 4.6, 0, lz))
			else:
				Builder.streetlight(seg, Vector3(side * 4.6, 0, lz), side)
	if biome == "village" and rng.randf() < 0.2:
		var b := Builder.make_vehicle(_find_vehicle("local_bus"))
		b.position = Vector3(6.2 * (1.0 if rng.randf() < 0.5 else -1.0), 0, -20)
		seg.add_child(b)
	if rng.randf() < 0.5:
		Builder.cloud(seg, Vector3(rng.randf_range(-30, 30), rng.randf_range(28, 40), -rng.randf_range(0, SEG_LEN)))

func _find_vehicle(id: String) -> Dictionary:
	for v in Game.vehicles:
		if v["id"] == id:
			return v
	return Game.vehicles[0]

func _item(seg: Node3D, biome: String, pos: Vector3, side: float) -> void:
	var r := rng.randf()
	if biome == "village":
		if r < 0.28: Builder.mango(seg, pos)
		elif r < 0.42: Builder.palm(seg, pos)
		elif r < 0.52: Builder.bamboo(seg, pos)
		elif r < 0.60: Builder.banana(seg, pos)
		elif r < 0.76: Builder.house(seg, pos)
		elif r < 0.82:
			pos.x = side * rng.randf_range(12.0, 18.0)
			Builder.pond(seg, pos)
		elif r < 0.90: Builder.cow(seg, pos)
		elif r < 0.94: Builder.mosque(seg, pos)
		else:
			pos.x = side * rng.randf_range(12.0, 18.0)
			Builder.paddy(seg, pos)
	elif biome == "city":
		pos.x = side * rng.randf_range(10.0, 14.0)
		if r < 0.55: Builder.building(seg, pos, side)
		elif r < 0.80: Builder.shop(seg, pos, side)
		else: Builder.mango(seg, pos)
	else:
		pos.x = side * rng.randf_range(10.0, 14.0)
		if side > 0:
			if r < 0.5: Builder.palm(seg, pos)
		elif r < 0.5: Builder.building(seg, pos, side)
		else: Builder.mango(seg, pos)

# ---------------- Traffic / coins (always leaves >=1 free lane) ----------------
func _spawn_row(zw: float) -> void:
	var order := [0, 1, 2]
	order.shuffle()
	var nblock: int = 1 if rng.randf() < 0.55 else 2
	for i in nblock:
		_spawn_obstacle(order[i], zw)
	var free_lane: int = order[2]
	if rng.randf() < 0.9:
		for j in 5:
			_spawn_item("coin", free_lane, zw - 2.5 * (j - 2))
	if rng.randf() < 0.06:
		_spawn_item(PU[rng.randi() % PU.size()], free_lane, zw - 9.0)
	if rng.randf() < 0.03:
		_spawn_item("heart", free_lane, zw - 6.5)

func _pick_vehicle() -> Dictionary:
	var tot := 0.0
	for v in Game.vehicles:
		tot += float(v["w"])
	var r := rng.randf() * tot
	for v in Game.vehicles:
		r -= float(v["w"])
		if r <= 0.0:
			return v
	return Game.vehicles[0]

func _spawn_obstacle(lane_i: int, z: float) -> void:
	var v := _pick_vehicle()
	var node := Builder.make_vehicle(v)
	var vels: Array = v["vel"]
	var vel: float = float(vels[rng.randi() % vels.size()])
	if vel > 0.0:
		node.rotation.y = PI
	node.position = Vector3(LANES[lane_i], 0, z)
	add_child(node)
	var s: Array = v["size"]
	var by := 0.0
	if str(v.get("kind", "block")) == "high":
		by = 1.1
	obstacles.append({"node": node, "hx": float(s[0]) / 2.0, "hz": float(s[2]) / 2.0, "by": by, "ty": float(s[1]), "vel": vel, "id": str(v["id"]), "horned": false})

func _spawn_item(kind: String, lane_i: int, z: float) -> void:
	var n := Node3D.new()
	n.position = Vector3(LANES[lane_i], 0.9, z)
	if kind == "coin":
		var m := Builder.cyl(n, 0.35, 0.35, 0.08, Vector3.ZERO, Color(1, 0.8, 0.1), Builder.coin_mat())
		m.rotation_degrees.x = 90.0
	elif kind == "heart":
		Builder.heart(n)
	else:
		Builder.sphere(n, 0.45, Vector3.ZERO, PU_COL[PU.find(kind)])
	add_child(n)
	items.append({"node": n, "kind": kind})
